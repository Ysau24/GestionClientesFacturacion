﻿
namespace CapaEntidad
{
    public class E_Base
    {
        private int _IdCliente;
        private int _IdFactura;

        public int IdCliente { get => _IdCliente; set => _IdCliente = value; }
        public int IdFactura { get => _IdFactura; set => _IdFactura = value; }
    }
}
