﻿

namespace CapaEntidad
{
    public class E_Login
    {
        private string _Usuario;
        private string _Contraseña;
       

        public string Usuario { get => _Usuario; set => _Usuario = value; }
        public string Contraseña { get => _Contraseña; set => _Contraseña = value; }
        
    }
}
