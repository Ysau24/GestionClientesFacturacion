﻿namespace CapaPresentacion
{
    partial class Clientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Clientes));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.LogInButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.closeButton = new System.Windows.Forms.Button();
            this.ClientesLabel = new System.Windows.Forms.Label();
            this.ListaDeClientes = new System.Windows.Forms.DataGridView();
            this.AgregarClientesButton = new System.Windows.Forms.Button();
            this.EliminarClientesButton = new System.Windows.Forms.Button();
            this.EditarClientesButton = new System.Windows.Forms.Button();
            this.ActualizarClientesButton = new System.Windows.Forms.Button();
            this.buttonBack = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BuscadorClientes = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.GuardarButtom = new System.Windows.Forms.Button();
            this.TelefonoTxt = new System.Windows.Forms.TextBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.CorreoTxt = new System.Windows.Forms.TextBox();
            this.NombreTxt = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ListaDeClientes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            this.panel1.Controls.Add(this.LogInButton);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.closeButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1598, 59);
            this.panel1.TabIndex = 5;
            // 
            // LogInButton
            // 
            this.LogInButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("LogInButton.BackgroundImage")));
            this.LogInButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.LogInButton.Dock = System.Windows.Forms.DockStyle.Right;
            this.LogInButton.FlatAppearance.BorderColor = System.Drawing.Color.BlueViolet;
            this.LogInButton.FlatAppearance.BorderSize = 0;
            this.LogInButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LogInButton.Location = new System.Drawing.Point(1494, 0);
            this.LogInButton.Name = "LogInButton";
            this.LogInButton.Size = new System.Drawing.Size(52, 59);
            this.LogInButton.TabIndex = 24;
            this.LogInButton.UseVisualStyleBackColor = true;
            this.LogInButton.Click += new System.EventHandler(this.LogInButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(51, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 22);
            this.label2.TabIndex = 23;
            this.label2.Text = "FACTUSOFT";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 16);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(24, 24);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // closeButton
            // 
            this.closeButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("closeButton.BackgroundImage")));
            this.closeButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.closeButton.Dock = System.Windows.Forms.DockStyle.Right;
            this.closeButton.FlatAppearance.BorderColor = System.Drawing.Color.BlueViolet;
            this.closeButton.FlatAppearance.BorderSize = 0;
            this.closeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.closeButton.Location = new System.Drawing.Point(1546, 0);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(52, 59);
            this.closeButton.TabIndex = 0;
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // ClientesLabel
            // 
            this.ClientesLabel.AutoSize = true;
            this.ClientesLabel.Font = new System.Drawing.Font("Montserrat", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClientesLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientesLabel.Location = new System.Drawing.Point(118, 106);
            this.ClientesLabel.Name = "ClientesLabel";
            this.ClientesLabel.Size = new System.Drawing.Size(310, 52);
            this.ClientesLabel.TabIndex = 19;
            this.ClientesLabel.Text = "Lista de clientes ";
            this.ClientesLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // ListaDeClientes
            // 
            this.ListaDeClientes.AllowUserToAddRows = false;
            this.ListaDeClientes.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(239)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Century Gothic", 12F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            this.ListaDeClientes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.ListaDeClientes.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(246)))), ((int)(((byte)(249)))));
            this.ListaDeClientes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Century Gothic", 12F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ListaDeClientes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.ListaDeClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Century Gothic", 12F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ListaDeClientes.DefaultCellStyle = dataGridViewCellStyle8;
            this.ListaDeClientes.Location = new System.Drawing.Point(127, 297);
            this.ListaDeClientes.Name = "ListaDeClientes";
            this.ListaDeClientes.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Century Gothic", 12F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ListaDeClientes.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.ListaDeClientes.RowHeadersWidth = 51;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.DarkGray;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Century Gothic", 12F);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.White;
            this.ListaDeClientes.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.ListaDeClientes.RowTemplate.Height = 24;
            this.ListaDeClientes.Size = new System.Drawing.Size(800, 342);
            this.ListaDeClientes.TabIndex = 20;
            // 
            // AgregarClientesButton
            // 
            this.AgregarClientesButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            this.AgregarClientesButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            this.AgregarClientesButton.FlatAppearance.BorderSize = 0;
            this.AgregarClientesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AgregarClientesButton.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.AgregarClientesButton.ForeColor = System.Drawing.Color.White;
            this.AgregarClientesButton.Image = ((System.Drawing.Image)(resources.GetObject("AgregarClientesButton.Image")));
            this.AgregarClientesButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AgregarClientesButton.Location = new System.Drawing.Point(127, 698);
            this.AgregarClientesButton.Name = "AgregarClientesButton";
            this.AgregarClientesButton.Size = new System.Drawing.Size(181, 53);
            this.AgregarClientesButton.TabIndex = 21;
            this.AgregarClientesButton.Text = "Agregar";
            this.AgregarClientesButton.UseVisualStyleBackColor = false;
            this.AgregarClientesButton.Click += new System.EventHandler(this.AgregarClientesButton_Click);
            // 
            // EliminarClientesButton
            // 
            this.EliminarClientesButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            this.EliminarClientesButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            this.EliminarClientesButton.FlatAppearance.BorderSize = 0;
            this.EliminarClientesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EliminarClientesButton.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.EliminarClientesButton.ForeColor = System.Drawing.Color.White;
            this.EliminarClientesButton.Image = ((System.Drawing.Image)(resources.GetObject("EliminarClientesButton.Image")));
            this.EliminarClientesButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.EliminarClientesButton.Location = new System.Drawing.Point(325, 698);
            this.EliminarClientesButton.Name = "EliminarClientesButton";
            this.EliminarClientesButton.Size = new System.Drawing.Size(187, 53);
            this.EliminarClientesButton.TabIndex = 22;
            this.EliminarClientesButton.Text = "Eliminar ";
            this.EliminarClientesButton.UseVisualStyleBackColor = false;
            this.EliminarClientesButton.Click += new System.EventHandler(this.EliminarClientesButton_Click);
            // 
            // EditarClientesButton
            // 
            this.EditarClientesButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            this.EditarClientesButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            this.EditarClientesButton.FlatAppearance.BorderSize = 0;
            this.EditarClientesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EditarClientesButton.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.EditarClientesButton.ForeColor = System.Drawing.Color.White;
            this.EditarClientesButton.Image = ((System.Drawing.Image)(resources.GetObject("EditarClientesButton.Image")));
            this.EditarClientesButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.EditarClientesButton.Location = new System.Drawing.Point(531, 698);
            this.EditarClientesButton.Name = "EditarClientesButton";
            this.EditarClientesButton.Size = new System.Drawing.Size(187, 53);
            this.EditarClientesButton.TabIndex = 23;
            this.EditarClientesButton.Text = "Editar";
            this.EditarClientesButton.UseVisualStyleBackColor = false;
            this.EditarClientesButton.Click += new System.EventHandler(this.EditarClientesButton_Click);
            // 
            // ActualizarClientesButton
            // 
            this.ActualizarClientesButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            this.ActualizarClientesButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            this.ActualizarClientesButton.FlatAppearance.BorderSize = 0;
            this.ActualizarClientesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ActualizarClientesButton.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.ActualizarClientesButton.ForeColor = System.Drawing.Color.White;
            this.ActualizarClientesButton.Image = ((System.Drawing.Image)(resources.GetObject("ActualizarClientesButton.Image")));
            this.ActualizarClientesButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ActualizarClientesButton.Location = new System.Drawing.Point(736, 698);
            this.ActualizarClientesButton.Name = "ActualizarClientesButton";
            this.ActualizarClientesButton.Size = new System.Drawing.Size(191, 53);
            this.ActualizarClientesButton.TabIndex = 24;
            this.ActualizarClientesButton.Text = "Actualizar";
            this.ActualizarClientesButton.UseVisualStyleBackColor = false;
            this.ActualizarClientesButton.Click += new System.EventHandler(this.ActualizarClientesButton_Click);
            // 
            // buttonBack
            // 
            this.buttonBack.BackColor = System.Drawing.SystemColors.Control;
            this.buttonBack.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            this.buttonBack.FlatAppearance.BorderSize = 0;
            this.buttonBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBack.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.buttonBack.ForeColor = System.Drawing.Color.White;
            this.buttonBack.Image = ((System.Drawing.Image)(resources.GetObject("buttonBack.Image")));
            this.buttonBack.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonBack.Location = new System.Drawing.Point(68, 106);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(43, 53);
            this.buttonBack.TabIndex = 25;
            this.buttonBack.UseVisualStyleBackColor = false;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(477, 225);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(428, 41);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // BuscadorClientes
            // 
            this.BuscadorClientes.BackColor = System.Drawing.SystemColors.Control;
            this.BuscadorClientes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BuscadorClientes.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BuscadorClientes.Location = new System.Drawing.Point(544, 236);
            this.BuscadorClientes.Name = "BuscadorClientes";
            this.BuscadorClientes.Size = new System.Drawing.Size(344, 20);
            this.BuscadorClientes.TabIndex = 27;
            this.BuscadorClientes.TextChanged += new System.EventHandler(this.BuscadorClientes_TextChanged);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(488, 232);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(24, 24);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 28;
            this.pictureBox3.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Controls.Add(this.GuardarButtom);
            this.panel2.Controls.Add(this.TelefonoTxt);
            this.panel2.Controls.Add(this.pictureBox6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.CorreoTxt);
            this.panel2.Controls.Add(this.NombreTxt);
            this.panel2.Controls.Add(this.pictureBox4);
            this.panel2.Controls.Add(this.pictureBox5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(1031, 59);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(567, 769);
            this.panel2.TabIndex = 29;
            // 
            // GuardarButtom
            // 
            this.GuardarButtom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            this.GuardarButtom.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(73)))), ((int)(((byte)(157)))));
            this.GuardarButtom.FlatAppearance.BorderSize = 0;
            this.GuardarButtom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GuardarButtom.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.GuardarButtom.ForeColor = System.Drawing.Color.White;
            this.GuardarButtom.Image = ((System.Drawing.Image)(resources.GetObject("GuardarButtom.Image")));
            this.GuardarButtom.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.GuardarButtom.Location = new System.Drawing.Point(190, 639);
            this.GuardarButtom.Name = "GuardarButtom";
            this.GuardarButtom.Size = new System.Drawing.Size(191, 53);
            this.GuardarButtom.TabIndex = 30;
            this.GuardarButtom.Text = "Guardar";
            this.GuardarButtom.UseVisualStyleBackColor = false;
            this.GuardarButtom.Click += new System.EventHandler(this.GuardarButtom_Click);
            // 
            // TelefonoTxt
            // 
            this.TelefonoTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TelefonoTxt.Enabled = false;
            this.TelefonoTxt.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TelefonoTxt.Location = new System.Drawing.Point(122, 485);
            this.TelefonoTxt.Name = "TelefonoTxt";
            this.TelefonoTxt.Size = new System.Drawing.Size(317, 20);
            this.TelefonoTxt.TabIndex = 40;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(110, 475);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(340, 39);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 39;
            this.pictureBox6.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 14F);
            this.label5.Location = new System.Drawing.Point(105, 422);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 30);
            this.label5.TabIndex = 38;
            this.label5.Text = "Teléfono";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 14F);
            this.label3.Location = new System.Drawing.Point(104, 298);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 30);
            this.label3.TabIndex = 37;
            this.label3.Text = "Correo";
            // 
            // CorreoTxt
            // 
            this.CorreoTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CorreoTxt.Enabled = false;
            this.CorreoTxt.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CorreoTxt.Location = new System.Drawing.Point(122, 359);
            this.CorreoTxt.Name = "CorreoTxt";
            this.CorreoTxt.Size = new System.Drawing.Size(317, 20);
            this.CorreoTxt.TabIndex = 36;
            // 
            // NombreTxt
            // 
            this.NombreTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NombreTxt.Enabled = false;
            this.NombreTxt.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NombreTxt.Location = new System.Drawing.Point(122, 239);
            this.NombreTxt.Name = "NombreTxt";
            this.NombreTxt.Size = new System.Drawing.Size(317, 20);
            this.NombreTxt.TabIndex = 35;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(110, 349);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(340, 39);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 34;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(110, 229);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(340, 39);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 32;
            this.pictureBox5.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 14F);
            this.label4.Location = new System.Drawing.Point(104, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 30);
            this.label4.TabIndex = 31;
            this.label4.Text = "Nombre";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Montserrat", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(138, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(298, 52);
            this.label1.TabIndex = 30;
            this.label1.Text = "Agregar cliente ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Clientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1598, 828);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.BuscadorClientes);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.ActualizarClientesButton);
            this.Controls.Add(this.EditarClientesButton);
            this.Controls.Add(this.EliminarClientesButton);
            this.Controls.Add(this.AgregarClientesButton);
            this.Controls.Add(this.ListaDeClientes);
            this.Controls.Add(this.ClientesLabel);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Clientes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "s";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ListaDeClientes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button LogInButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label ClientesLabel;
        private System.Windows.Forms.DataGridView ListaDeClientes;
        private System.Windows.Forms.Button AgregarClientesButton;
        private System.Windows.Forms.Button EliminarClientesButton;
        private System.Windows.Forms.Button EditarClientesButton;
        private System.Windows.Forms.Button ActualizarClientesButton;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox BuscadorClientes;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox CorreoTxt;
        private System.Windows.Forms.TextBox NombreTxt;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TelefonoTxt;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button GuardarButtom;
    }
}