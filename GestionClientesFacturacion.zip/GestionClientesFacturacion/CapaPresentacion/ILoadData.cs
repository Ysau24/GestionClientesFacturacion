﻿
namespace CapaPresentacion
{
    public interface ILoadData
    {
         void LoadData();
    }
}
